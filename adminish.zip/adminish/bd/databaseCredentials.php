
<?php
$host = "localhost";
	$user = "root";
	$pw = "";
	$db = "adminish";
?>