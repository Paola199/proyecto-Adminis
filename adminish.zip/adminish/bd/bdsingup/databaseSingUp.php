
<?php
include("../databaseCredentials.php");
if(isset($_POST['correo']) && !empty ($_POST['correo'])&&isset($_POST['clave']) && !empty ($_POST['clave']))
{
 $conex = mysqli_connect($host,$user,$pw) or die("Problemas al conectar el servidor"); //conectar con el servidor
 mysqli_select_db($conex,$db);("Problemas al conectar la base de datos");//seleccionar la base de datos
 mysqli_query($conex,"INSERT INTO singup (correo,clave) VALUES('$_POST[correo]','$_POST[clave]')");//insertar los datos
 
 echo "datos insertados";
}
else
{
 echo "Problemas al insertar datos";

}

?>
