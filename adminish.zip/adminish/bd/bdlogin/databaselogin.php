
<?php  
include("../databaseCredentials.php");

  session_start();
  if (!empty($_POST['correo']) && !empty($_POST['clave'])) 
  {
    $con= mysqli_connect($host,$user,$pw) or die ("problemas al conectar con el host");
    mysqli_select_db ($con,$db) or die ("problemas al conectar la base de datos");
    $registro= mysqli_query ($con, "SELECT * FROM singup WHERE correo = '$_POST[correo]'")or die ("Problemas en consulta". mysqli_error());
    while ($reg=mysqli_fetch_array($registro)) //estrayendo la informacion para conparar.
    {
      $password = $_POST['clave'];
      if($reg['clave'] == $password){
        echo "bien falta ingresar a empresa";
      }else
        { 
          header("Location: http://localhost/adminish/modelo/loginIndex.php");
          die();
        } 
    }  
  }  
  ?>
 

 

