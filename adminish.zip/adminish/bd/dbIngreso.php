<?php 

include("databaseCredentials.php");

if (isset($_POST['codigo']) && empty ($_POST['codigo'])||isset($_POST['descripcion']) && empty ($_POST['descripcion'])||isset($_POST['unidad_medida']) && empty ($_POST['unidad_medida'])){
	
	$codigo=0;
	$descripcion="";
	$unidad_medida=" ";

}else{

	$codigo=$_POST['codigo'];
	$descripcion=$_POST['descripcion'];
	$unidad_medida=$_POST['unidad_medida'];

}

$tot= $_POST['precio_unitario']*$_POST['cant'];

if(isset($_POST['nombre']) && !empty ($_POST['nombre'])&&isset($_POST['precio_unitario']) && !empty ($_POST['precio_unitario'])&&isset($_POST['cant']) && !empty ($_POST['cant']))
{
 $conex = mysqli_connect($host,$user,$pw) or die("Problemas al conectar el servidor"); //conectar con el servidor
 mysqli_select_db($conex,$db)or die("Problemas al conectar la base de datos");//seleccionar la base de datos
 mysqli_query($conex,"INSERT INTO ingresos (codigo,nombre,descripcion,precio_unitario,unidad_medida, cant, total) VALUES($codigo,'$_POST[nombre]',$descripcion,'$_POST[precio_unitario]',$unidad_medida,'$_POST[cant]',$tot)")or die("Problemas al conectar el servidor1");//insertar los datos
 
 echo "datos insertados";
}else
{
 echo "Problemas al insertar datos";
}
?>

