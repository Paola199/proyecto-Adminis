<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0">
	<title>
		registro
	</title>
	
	<link rel="stylesheet" href="..\css\bootstrap.min.css" crossorigin="anonymous">
	
	<script src="..\js\bootstrap.min.js" crossorigin="anonymous"></script>
</head>
<body>
	
	<br><br><br>
	<div class="container" align="center">
        <div class="col-6" align="center">
        <div class="card card-container">
        	<center><br><img src="../img/logo.png" width="250" height="200">
                <h1 style="color: #155B77; ">Adminish</h1>
            </center>
            <p id="profile-name" class="profile-name-card"></p>
            <div class="section-double-item section-double-item-light">
          	<div class="section-double-content">
            <h2 class="text-accent">Inicio de Sesi&oacuten</h2>
		<form action="../bd/bdlogin/databaselogin.php" method="post" name="formulario">
			<div class="form-group col-md-4">
				<input class="form-control" type="text" name="correo" placeholder="E-mail"><br><br>
			</div>
			<div class="form-group col-md-4"> 
				<input class="form-control" type="password" name="clave" placeholder="Clave"><br><br>	
			</div>
		<button type="submit" class="btn btn-outline-info">Iniciar Secion</button>
		
	</div><br>
	</form>
		</div>
		</div>
	</div>
	<br><br>
</body>
</html>