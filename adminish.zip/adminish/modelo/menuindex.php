<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0">
	<title></title>
	<link rel="stylesheet" href="..\css\bootstrap.min.css" crossorigin="anonymous">
	<script src="..\js\bootstrap.min.js" crossorigin="anonymous"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light ">
  <div class="container-fluid ">
    <a class="nav-link active" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNav">
      <ul class="navbar-nav border border-light">
      	<div class="border-end border-bottom border-info">
      		<li class="nav-item ">
          	<a class="nav-link active" aria-current="page" href="#">Home</a>
        	</li>
      	</div>
        <div class= "border-end border-bottom border-info">
        	<li class="nav-item ">
          	<a class="nav-link active" href="#">Features</a>
        	</li>
        </div>
        <div class= " border-end border-bottom border-info">
        	<li class="nav-item ">
          	<a class="nav-link active" href="#">Pricing</a>
       		</li>
        </div>
       <div  class= "border-end border-bottom border-info">
       	 <li class="nav-item ">
          <a class="nav-link active " href="#" tabindex="-1" aria-disabled="true">Disabled</a>
        </li>
       </div>
       
      </ul>
    </div>
  </div>
</nav>
</body>
</html>