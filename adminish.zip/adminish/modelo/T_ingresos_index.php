<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0">
	<title>ingresos</title>
	<link rel="stylesheet" href="..\css\bootstrap.min.css" crossorigin="anonymous">
	<script src="..\js\bootstrap.min.js" crossorigin="anonymous"></script>
</head>
<body>

<br><br>
<div class="container position-static" >
	<img src="../img/logo.png" width="65" height="55" >
	<?php 
	include('menuindex.php');
	?>
</div>

<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown
<div class="container">
	<form action="../bd/dbIngreso.php" method="post" name="formulario">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4"></label>
      <input type="number" class="form-control" name= "codigo" placeholder=codigo>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4"></label>
      <input type="text" class="form-control" name="nombre" placeholder="Producto">
    </div>
  </div>
   <div class="form-group">
    <label for="exampleFormControlTextarea1"></label>
     <input type="text" class="form-control" name="descripcion" placeholder="descripcion">
  </div>
  <div class="form-group">
    <label for="inputAddress2"></label>
    <input type="number" class="form-control" name="precio_unitario" placeholder="precio unitario">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity"></label>
      <input type="text" class="form-control" name="unidad_medida" placeholder="unidad de medida">
    </div>
    <!-- aqui queso el iva

 <div class="form-group col-md-4">
      <label for="inputState"></label>
      <select name="iva" class="form-control">
        <option size= "1">iva 19%</option>
        <option size= "2">iva 5%</option>
      </select>
    </div>

    <input type="text" class="form-control" name="descripcion" placeholder="precio unitario">
            -->
    <div class="form-group col-md-6">
      <label for="inputCity"></label>
      <input type="number" class="form-control" name="cant" placeholder="cantidad">
    </div>
  </div>
  <button type="submit" class="btn btn-outline-info">agregar</button>
</form>
</a>
</li>

  <div class="row" align="center">

     <table align="center" class="table"">
      <thead class="color">
        <tr>         
          <td scope="col">Codigo</td>
          <td scope="col">Producto</td>
          <td scope="col">Descripcion</td>
          <td scope="col">Precio Uni</td>
           <td scope="col">Iva</td>
          <td scope="col">Unidad de medida</td>
           <td scope="col">Cantidad</td>
          <td scope="col">total</td>
      </thead>
      
    </table>

    <!-- nueva fila -->
    <div class="w-100"></div>

   
  </div>
</div><br><BR></BR>

	


</body>
</html>